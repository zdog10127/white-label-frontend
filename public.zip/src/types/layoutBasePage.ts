export interface LayoutBasePageProps {
  title: string;
  children: React.ReactNode;
  toolsBar?: React.ReactNode;
}
