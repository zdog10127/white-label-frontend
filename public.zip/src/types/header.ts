export interface HeaderProps {
  onMenuClick?: () => void;
  title?: string;
}
