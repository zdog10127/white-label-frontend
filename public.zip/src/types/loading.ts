export interface LoadingProps {
  fullScreen?: boolean;
  size?: number;
  padding?: number;
}
