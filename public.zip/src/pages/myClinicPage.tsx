const MyClinicPage = () => {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>Minha Clínica</h1>
      <p>Página em desenvolvimento...</p>
    </div>
  );
};

export default MyClinicPage;