const FinancialPage = () => {
  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <h1>Financeiro</h1>
      <p>Página em desenvolvimento...</p>
    </div>
  );
};

export default FinancialPage;
