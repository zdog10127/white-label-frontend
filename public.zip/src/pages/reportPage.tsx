const ReportPage = () => {
  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>Relatórios</h1>
      <p>Página em desenvolvimento...</p>
    </div>
  );
};

export default ReportPage;