const SettingsPage = () => {
  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <h1>Configurações</h1>
      <p>Página em desenvolvimento...</p>
    </div>
  );
};

export default SettingsPage;
